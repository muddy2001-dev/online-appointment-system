<?php
include_once '../database.php';

$id = intval($_GET['id']);
$response = [];

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $response['success'] = "Student deleted successfully.";
    } else {
        $response['error'] = "Failed to delete student.";
    }
    $stmt->close();
} else {
    $response['error'] = "Invalid student ID.";
}

$conn->close();
echo json_encode($response);
?>
