
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification</title>
    <style>
           body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f2f5f7;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color:#2c3e50;
            color: white;
            display: flex;
            justify-content: space-between;
            padding: 5px 10px;
            align-items: center;
        }
        .navbar .nav-links button {
            background: #3498db;
            border: none;
            padding: 5px 10px;
            color: #fff;
            cursor: pointer;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h3 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color:  #2c3e50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <nav class="navbar">
  <div class="logo">SRMS</div>
  <div class="nav-links">
     <button onclick="window.location.href='login.php'" style="border-radius: 10px; padding: 6px 12px; background-color: white; color: black; border: none; cursor: pointer;">
      Back
    </button>
  </div>
</nav>
    <div class="container">
        <form method="post" action="l13c.php">
            <h3>OTP Verification</h3>
            <label for="otp">Enter the OTP that was sent to your email:</label><br>
            <input type="number" name="otp" required><br>

            <input type="submit" value="Verify">
        </form>
    </div>
</body>
</html>
