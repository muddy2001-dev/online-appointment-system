<?php
// Show all errors for development
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Optional: set a custom error handler to log errors
set_error_handler(function ($severity, $message, $file, $line) {
    $logMessage = "[" . date('Y-m-d H:i:s') . "] Error: $message in $file on line $line\n";
    // Log to file
    file_put_contents(__DIR__ . '/errors.log', $logMessage, FILE_APPEND);
    // Optionally display on page (for dev)
    echo json_encode(['success' => '', 'error' => $logMessage]);
    exit;
});

// Optional: handle uncaught exceptions
set_exception_handler(function($exception) {
    $logMessage = "[" . date('Y-m-d H:i:s') . "] Uncaught Exception: " . $exception->getMessage() . "\n";
    file_put_contents(__DIR__ . '/errors.log', $logMessage, FILE_APPEND);
    echo json_encode(['success' => '', 'error' => $logMessage]);
    exit;
});
