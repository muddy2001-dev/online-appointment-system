<?php
include_once '../database.php';

$result = $conn->query("SELECT * FROM students ORDER BY id DESC LIMIT 10");

echo "<h2>Registered Students</h2>";
echo "<table border='1' cellpadding='8'>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Reg. Number</th>
            <th>Phone</th>
            <th>Gender</th>
            <th>Class</th>
            <th>Section</th>
             <th>Date Of Birth</th>
<th>Registration Date</th>
        </tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['regno']}</td>
             <td>{$row['phone']}</td>
              <td>{$row['gender']}</td>
               <td>{$row['class']}</td>
                <td>{$row['section']}</td>
                 <td>{$row['dob']}</td>
                  <td>{$row['created_at']}</td>
        </tr>";
}

echo "</table>";

$conn->close();
?>
