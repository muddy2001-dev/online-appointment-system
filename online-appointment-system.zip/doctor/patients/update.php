
<?php
include_once __DIR__ . '/../database.php';
session_name("user_session");
session_start();

if (!isset($_SESSION['user']['id']) && !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Normalize ID variable
$userId = $_SESSION['user']['id'] ?? $_SESSION['user_id'];


$fullName = $email = $phone = "";
$message = "";

// Fetch existing user data
$stmt = $conn->prepare("SELECT name, email, phone FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $name = $user['name'];
    $email = $user['email'];
    $phone = $user['phone'];
}
$stmt->close();

// Update logic
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);

    // Check if email is taken by other user
    $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $checkStmt->bind_param("si", $email, $userId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        // Email already taken by another user
        $message = "⚠️ This email address is already in use by another account. Please use a different email.";
    } else {
        // Proceed with update
        $stmt = $conn->prepare("UPDATE users SET name=?, email=?, phone=? WHERE id=?");
        $stmt->bind_param("sssi", $name, $email, $phone, $userId);

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $currentDateTime = date('Y-m-d H:i:s'); // current timestamp
                $successMessage = "Your details have been updated successfully on $currentDateTime.";

                // Save notification to database
                $notifStmt = $conn->prepare("INSERT INTO notifications (user_id, message, is_read, created_at) VALUES (?, ?, 0, NOW())");
                $notifStmt->bind_param("is", $userId, $successMessage);
                $notifStmt->execute();
                $notifStmt->close();

                $message = "✅ Details updated successfully.";
            } else {
                $message = "ℹ️ No changes made (data may be the same).";
            }
        } else {
            // For any other DB error, fallback to generic message
            $message = "❌ An unexpected error occurred while updating your details. Please try again.";
        }

        $stmt->close();
    }

    $checkStmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
    font-family: 'Segoe UI', sans-serif;
    background: #f0f2f5;
    margin: 0;
    padding: 0;
    overflow: hidden; /* disables scrolling */
    height: 100vh;     /* make body fill the viewport */
}


        .container {
            max-width: 450px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: 500;
        }
        
                 .navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
background-color: #2c3e50;
    color: white;
    display: flex;
    justify-content: space-between;
    padding: 5px 10px;
    align-items: center;
    z-index: 1000; /* stays above other content */
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
}

       

        .navbar .nav-links a {
            color: white;
            margin-left: 15px;
            text-decoration: none;
        }

        .navbar .nav-links a:hover {
            text-decoration: underline;
        }

        input[type="text"], input[type="email"], input[type="tel"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            margin-top: 5px;
            border: 1px solid #ccc;
        }

        button {
            margin-top: 8px;
            width: 100%;
            padding: 12px;
            background-color: #2c3e50;
            color: white;
            border: none;
       
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .message {
            margin-top: 15px;
            padding: 10px;
            border-radius: 5px;
            background-color: #f1f1f1;
            font-size: 15px;
        }

        .message strong {
            display: block;
        }

        @media (max-width: 500px) {
            .container {
                margin: 20px;
                padding: 20px;
            }
        }

        .settings-options {
    max-width: 450px;       /* same width as container */
    margin: 20px auto 50px; /* space above and below, centered */
    display: flex;
    justify-content: space-between;
    gap: 15px;
}

.settings-options a {
    flex: 1;
    text-align: center;
    padding: 12px 0;
  background-color: #2c3e50;
    color: white;
    border-radius: 5px;
    text-decoration: none;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s ease;
    user-select: none;
}

.settings-options a:hover {
    background-color: #0056b3;
}

@media (max-width: 500px) {
    .settings-options {
        flex-direction: column;
    }
    .settings-options a {
        flex: unset;
        margin-bottom: 10px;
    }
}
        /* Dark mode styling */


    </style>
   

</head>
<body>
    <nav class="navbar">
    <div class="logo">OPS</div>
    <div class="nav-links">
<div class="p">
<button onclick="window.location.href='index.php'" style=" padding: 4px 8px; background-color: white; color: black; border: none; cursor: pointer;">
  Home
   </button>
</div>
            

    </div>
</nav>
    <div class="container">
        <h2>Update Your Details</h2>

        <?php if ($message): ?>
            <div class="message"><strong><?= htmlspecialchars($message) ?></strong></div>
        <?php endif; ?>

        <form method="post" action="update.php">
            <label>Full name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>

            <label>Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

            <label>Phone</label>
            <input type="tel" name="phone" value="<?= htmlspecialchars($phone) ?>" required>
             <button type="submit">Update Details</button>

   <div class="settings-options">
           
             <a href="change_password.php">Change Password</a>
             <a href="delete_account.php">Delete Account</a>
           
        </div>
           
     
           
        </div>
        </form>
       
    </div>
       
</body>
</html>
