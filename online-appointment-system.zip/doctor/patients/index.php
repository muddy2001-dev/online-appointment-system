<?php
session_name("user_session");
session_start();
if (!isset($_SESSION['user_id'])) {
    // Not logged in, redirect to login page or show error
    header("Location: login.php");
    exit();
}

$initial = '?';

if (isset($_SESSION['user_email'])) {
    $initial = strtoupper(substr($_SESSION['user_email'], 0, 1));
} elseif (isset($_SESSION['email'])) {
    $initial = strtoupper(substr($_SESSION['email'], 0, 1));
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient Dashboard</title>
    <link rel="stylesheet" href="style.css">

<script>
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: 'en',
    includedLanguages: 'en,sw',
    layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL
  }, 'google_translate_element');
}
</script>


<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <nav class="navbar">
    <div class="logo"> User Dashboard</div>
    <div id="google_translate_element" style="margin-left: 15px;"></div>

    
    <div class="nav-links">
     <a href="notifications.php" title="Notifications" style="position: relative;">
  🔔
  <span id="notificationBadge"
        style="position: absolute; top: -5px; right: -5px; background: red; color: white; 
               border-radius: 50%; padding: 2px 6px; font-size: 12px; display: none;">
  </span>
</a>

    
   
         <div class="profile-dropdown">
    <a href="javascript:void(0);" class="profile-circle" id="profileBtn" title=""><?= $initial ?></a>
    <div class="dropdown-content" id="profileMenu">
        <a href="views.php">Your Details</a>
        <a href="javascript:void(0);" onclick="confirmLogout()">Logout</a>
    </div>
</div>
    </div>
  </nav>

<script>
document.addEventListener("DOMContentLoaded", function () {
    fetch("get_unread_notifications.php")
        .then(response => response.json())
        .then(data => {
            const badge = document.getElementById("notificationBadge");
            if (data.count > 0) {
                badge.innerText = data.count;
                badge.style.display = "inline-block";
            } else {
                badge.style.display = "none";
            }
        })
        .catch(error => console.error("Error loading notifications:", error));
});
</script>


    <h2>Welcome to Your Dashboard</h2>

    <div class="dashboard-cards">
        <a href="book.php" class="card-link">
            <div class="card">
                <div class="card-logo">📝</div>
                <strong>Book Appointment</strong>
            </div>
        </a>

        <a href="appointments.php" class="card-link">
            <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>My Appointments</strong>
            </div>
        </a>

            <a href="reschedule.php" class="card-link">
    <div class="card">
        <div class="card-logo">🔄</div>
        <strong>Reschedule</strong>
    </div>
</a>

        <a href="update.php" class="card-link">
            <div class="card">
                <div class="card-logo">⚙️</div>
                <strong>Settings</strong>
            </div>
        </a>
    
    <a href="view_slots.php" class="card-link">
    <div class="card">
        <div class="card-logo">🕒</div>
        <strong>This week</strong>
    </div>
</a>

    </div>
    <script>
function confirmLogout() {
    if (confirm("Are you sure you want to logout?")) {
        window.location.href = "logout.php";
    }
}
</script>

    
<script>document.addEventListener('DOMContentLoaded', function() {
    const profileBtn = document.getElementById('profileBtn');
    const profileMenu = document.getElementById('profileMenu');
    const profileDropdown = profileBtn.parentElement;

    profileBtn.addEventListener('click', function(e) {
        e.preventDefault();
        profileDropdown.classList.toggle('show');
    });

    // Close dropdown if clicking outside
    window.addEventListener('click', function(e) {
        if (!profileDropdown.contains(e.target)) {
            profileDropdown.classList.remove('show');
        }
    });
});
</script>

<footer class="footer">
  <div class="footer-container">
    <div class="footer-column">
      <div class="footer-logo">
      
        <div>
                </div>
      </div>
       <h3>JK Hospital</h3>
          
      <p><i class="fa fa-map-marker"></i>Mikadi ,Kigamboni, Dar es Salaam, Tanzania</p>
      <p><i class="fa fa-phone"></i> 0678101010</p>
      <p><i class="fa fa-envelope"></i> www.jkhospital.or.tz</p>
    </div>

    <div class="footer-column">
      <h3>Quick Links</h3>
      <ul>
       
        <li><a href="about_us.php">About Us</a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="faq.php">FAQs</a>
         <li><a href="event.php">Upcoming Events</a>
</li>
      </ul>
    </div>

   <div class="footer-column">
  <h3>Hours <i class="fa fa-clock-o"></i></h3>
  <p><strong>Open 24/7</strong><br> Including weekends and public holidays</p>
</div>


  <div class="footer-column">
    <h3>Social Media</h3>
  <div class="social-icons">
  <a href="https://www.facebook.com/yourpage" target="_blank" title="Facebook">
    <i class="fa fa-facebook"></i>
  </a>
  <a href="https://www.twitter.com/yourhandle" target="_blank" title="Twitter">
    <i class="fa fa-twitter"></i>
  </a>
  <a href="https://www.instagram.com/yourprofile" target="_blank" title="Instagram">
    <i class="fa fa-instagram"></i>
  </a>
  <a href="https://www.linkedin.com/company/yourcompany" target="_blank" title="LinkedIn">
    <i class="fa fa-linkedin"></i>
  </a>
  
</div>

   
  </div>
<div class="footer-bottom">
  &copy; 2025 OPS Hospital. All rights reserved.
</div>


</footer>


</body>
</html>
