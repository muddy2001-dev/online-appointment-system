<?php
include_once __DIR__ . '/../database.php';
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirmPassword"];

    // Server-side validations
    if (!preg_match('/^([A-Za-z\'\-]{2,}\s+){1,}[A-Za-z\'\-]{2,}$/', $name)) {
        $errors[] = "Please enter a valid full name (e.g., Joe Hart).";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (!preg_match('/^0[67][0-9]{8}$/', $phone)) {
        $errors[] = "Phone number must be a valid Tanzanian number (e.g., 0655123456).";
    }

    if (strlen($password) < 6 || !preg_match('/[a-zA-Z]/', $password) || !preg_match('/[!@#$%^&*()]/', $password)) {
        $errors[] = "Password must be at least 6 characters long, contain letters and a special character.";
    }

    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    // Check for duplicate email
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $errors[] = "An account with this email already exists.";
    }
    $stmt->close();

    // Insert user if no errors
    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $phone, $hashedPassword);

        if ($stmt->execute()) {
            $user_id = $stmt->insert_id;

            // User notification
            $notif_stmt = $conn->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
            $message = "Welcome to OPS! Your account has been successfully created.";
            $notif_stmt->bind_param("is", $user_id, $message);
            $notif_stmt->execute();
            $notif_stmt->close();

            // Admin notification
            $admin_message = "New user signed up: $name ($email)";
            $admin_stmt = $conn->prepare("INSERT INTO admin_notifications (message) VALUES (?)");
            $admin_stmt->bind_param("s", $admin_message);
            $admin_stmt->execute();
            $admin_stmt->close();

            header('Location: login.php');
            exit();
        } else {
            $errors[] = "Database error: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Signup</title>
<style>
body { font-family: sans-serif; background: #f0f0f0; margin:0; padding:0; }
.navbar { position: fixed; top:0; left:0; right:0; background-color:#2c3e50; color:white; display:flex; justify-content:space-between; padding:13px 20px; align-items:center; z-index:1000; box-shadow:0 2px 6px rgba(0,0,0,0.2);}
.navbar .logo { font-size:22px; font-weight:bold; }
.navbar button { border-radius: 10px; padding: 6px 12px; background:white; color:black; border:none; cursor:pointer; }
.container { max-width: 400px; background:white; padding:30px; margin:100px auto; border-radius:10px; box-shadow:0 4px 10px rgba(0,0,0,0.1);}
h3 { text-align:center; color:#333; }
label { display:block; margin-bottom:5px; color:#333; }
input[type="text"], input[type="email"], input[type="tel"], input[type="password"] { width:100%; padding:10px; margin-bottom:15px; border:1px solid #ccc; border-radius:4px; box-sizing:border-box; }
button[type="submit"] { background-color:#2c3e50; color:#fff; padding:10px; border:none; border-radius:4px; cursor:pointer; width:100%; }
button[type="submit"]:hover { background-color:#0056b3; }
.error { color:red; margin-bottom:10px; text-align:center; }
.password-toggle { position: absolute; right:10px; top:10px; cursor:pointer; }
.password-container { position:relative; }
</style>
</head>
<body>
<nav class="navbar">
    <div class="logo">OPS</div>
    <button onclick="window.location.href='login.php'">Login</button>
</nav>

<div class="container">
<form method="post" action="signup.php" id="signupForm">
<h3>Signup Form</h3>

<?php
if(!empty($errors)){
    foreach($errors as $e){
        echo "<p class='error'>$e</p>";
    }
}
?>

<label for="name">Full Name:</label>
<input type="text" id="fullName" name="name" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">

<label for="email">Email:</label>
<input type="email" id="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

<label for="phone">Phone:</label>
<input type="tel" id="phone" name="phone" pattern="0[67][0-9]{8}" maxlength="10" required value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">

<label for="password">Password:</label>
<div class="password-container">
<input type="password" id="password" name="password" required>
<span class="password-toggle" onclick="togglePassword('password')">👁️</span>
</div>

<label for="confirmPassword">Confirm Password:</label>
<div class="password-container">
<input type="password" id="confirmPassword" name="confirmPassword" required>
<span class="password-toggle" onclick="togglePassword('confirmPassword')">👁️</span>
</div>

<button type="submit">Sign Up</button>
</form>
</div>

<script>
function togglePassword(id){
    const input = document.getElementById(id);
    input.type = input.type === 'password' ? 'text' : 'password';
}

document.getElementById('phone').addEventListener('input', function () {
    this.value = this.value.replace(/\D/g,'').slice(0,10);
});
</script>
</body>
</html>
