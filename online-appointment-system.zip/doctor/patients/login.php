
<?php
session_name("user_session");
session_start();

$errors = ['email' => '', 'password' => ''];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include_once __DIR__ . '/../database.php';

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Enter a valid email.";
    }

    if (empty($errors['email'])) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();

     if ($res->num_rows === 1) {
    $user = $res->fetch_assoc();

    if ($user['is_blocked']) {
        $errors['email'] = "Your account has been blocked. Please contact the administrator.";
    } elseif (password_verify($password, $user['password'])) {
        $_SESSION['user'] = $user;
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['patient_id'] = $user['id'];
        $_SESSION['email'] = $user['email'];




        if ($email === "admin@example.com") {
            header("Location: admindashboard.php");
        } elseif ($email === "reception@example.com") {
            header("Location: receptionistdashboard.php");
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        $errors['password'] = "Incorrect password.";
    }
} else {
    $errors['email'] = "No account found with that email.";
}

        $stmt->close();
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MASS Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        :root {
            --main-blue: #007bff;
            --main-dark: #0056b3;
            --background: #f0f4f8;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: var(--background);
        }

   
      .navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background-color: #2c3e50;
    color: white;
    display: flex;
    justify-content: space-between;
    padding: 5px 10px;
    align-items: center;
    z-index: 1000; /* ensures it stays above everything */
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
}

        .navbar .logo {
            font-size: 22px;
            font-weight: 700;
        }

  

      

        .form-container {
            max-width: 420px;
            background: #fff;
            padding: 35px;
            margin: 60px auto;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        }

        .login-form h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            color: #444;
        }

        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
            transition: border-color 0.3s ease;
        }

        input[type="email"]:focus, input[type="password"]:focus {
            border-color: var(--main-blue);
            outline: none;
        }

        .error {
            color: red;
            font-size: 13px;
            margin-bottom: 10px;
        }

        .highlight-error {
            border-color: red;
        }

        button[type="submit"] {
            width: 100%;
            padding: 13px;
            font-size: 16px;
            background-color: #2c3e50;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button[type="submit"]:hover {
            background: var(--main-dark);
        }

        .forgot-password {
            text-align: right;
            margin-top: 12px;
        }

        .forgot-password a {
            font-size: 14px;
            color: var(--main-blue);
            text-decoration: none;
        }

        .forgot-password a:hover {
            text-decoration: underline;
        }

        @media (max-width: 500px) {
            .form-container {
                margin: 30px 15px;
                padding: 25px;
            }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">OPS</div>
        <div class="nav-links">
             <button onclick="window.location.href='signup.php'" style="border-radius: 10px; padding: 4px 8px; background-color: white; color: black; border: none; cursor: pointer;">
      Signup
    </button>
        </div>
    </nav>

    <div class="form-container">
        <form method="POST" action="login.php" class="login-form">
            <h2>Login</h2>

            <label>Email</label>
            <input 
                type="email" 
                name="email" 
                value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" 
                class="<?= $errors['email'] ? 'highlight-error' : '' ?>" 
                required
            >
            <p class="error"><?= $errors['email'] ?></p>

            <label>Password</label>
            <input 
                type="password" 
                name="password" 
                class="<?= $errors['password'] ? 'highlight-error' : '' ?>" 
                required
            >
            <p class="error"><?= $errors['password'] ?></p>

            <button type="submit">Login</button>

            <div class="forgot-password">
                <a href="forgot-password.php">Forgot Password?</a>
            </div>
        </form>
    </div>

</body>
</html>
