<?php
session_name("user_session");
session_start();

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/../database.php';

$errors = ['password' => '', 'new_password' => '', 'confirm_password' => ''];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentPassword = trim($_POST['password']);
    $newPassword     = trim($_POST['new_password']);
    $confirmPassword = trim($_POST['confirm_password']);

    $userId = $_SESSION['user_id'];

    // Fetch user
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();

        // Check current password
        if (!password_verify($currentPassword, $user['password'])) {
            $errors['password'] = "Current password is incorrect.";
        }

        // Validate new password
        if (strlen($newPassword) < 6) {
            $errors['new_password'] = "New password must be at least 6 characters.";
        } elseif ($newPassword !== $confirmPassword) {
            $errors['confirm_password'] = "Passwords do not match.";
        }

        // If no errors, update password
        if (empty(array_filter($errors))) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $update = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $update->bind_param("si", $hashedPassword, $userId);

            if ($update->execute()) {
                $success = "Password changed successfully.";
            } else {
                $errors['new_password'] = "Failed to update password. Try again.";
            }

            $update->close();
        }
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Change Password</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #f0f4f8;
        }

        .navbar {
            background-color: #2c3e50;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        }

        .navbar .logo {
            font-size: 22px;
            font-weight: 700;
        }

        .form-container {
            max-width: 450px;
            background: #fff;
            padding: 35px;
            margin: 60px auto;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
        }

        input[type="password"] {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }

        .error {
            color: red;
            font-size: 13px;
            margin-bottom: 10px;
        }

        .success {
            color: green;
            font-size: 14px;
            text-align: center;
            margin-top: 10px;
        }

        button[type="submit"] {
            width: 100%;
            padding: 13px;
            font-size: 16px;
            background-color: #2c3e50;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background: #0056b3;
        }

        @media (max-width: 500px) {
            .form-container {
                margin: 30px 15px;
                padding: 25px;
            }
        }
    </style>
</head>
<body>

   <nav class="navbar">
    <div class="logo">OPS</div>

    <div id="clock" style="font-weight: bold; font-size: 18px; color: white;"></div>

    <div class="nav-links">
        <button onclick="window.location.href='index.php'" style="border-radius: 10px; padding: 8px 16px; background-color: white; color: black; border: none; cursor: pointer;">
          Home
        </button>
    </div>
</nav>

<div class="form-container">
    <form method="POST" action="">
        <h2>Change Password</h2>

        <label>Current Password</label>
        <input type="password" name="password">
        <p class="error"><?= $errors['password'] ?></p>

        <label>New Password</label>
        <input type="password" name="new_password">
        <p class="error"><?= $errors['new_password'] ?></p>

        <label>Confirm New Password</label>
        <input type="password" name="confirm_password">
        <p class="error"><?= $errors['confirm_password'] ?></p>

        <button type="submit">Change Password</button>

        <?php if (!empty($success)): ?>
            <p class="success"><?= $success ?></p>
        <?php endif; ?>
    </form>
</div>

</body>
</html>
