-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2025 at 01:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctor`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fullName` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `otp` varchar(255) NOT NULL,
  `otp_generated_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fullName`, `email`, `phone`, `password`, `otp`, `otp_generated_time`, `is_read`, `created_at`) VALUES
(13, 'Admin Admin', 'admin@example.com', '077777775', '$2y$10$d6AsaPt1niyO42fwp12ZF.NXig.O5ed/j/.nfMjs6eHjGUqKJ9GWK', '', '2025-09-15 14:24:34', 0, '2025-09-03 12:53:52');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_notifications`
--

INSERT INTO `admin_notifications` (`id`, `message`, `is_read`, `created_at`) VALUES
(1, 'New user signed up: MOH\'D MOH\'D (mrawadhi2005@gmail.com)', 1, '2025-08-31 07:04:39'),
(2, 'New user signed up: MOH\'D MOH\'D (mrawadhi2005@gmail.com)', 1, '2025-08-31 07:07:33'),
(3, 'New user signed up: MOH\'D MOH\'D (mrawadhi2005@gmail.com)', 1, '2025-09-03 14:41:35'),
(4, 'New user signed up: TIME ALI RASHID (mrawadhi2005@gmail.com)', 1, '2025-09-15 14:30:48'),
(6, 'New user signed up: TIME ALI RASHID (mrawadhi2005@gmail.com)', 1, '2025-09-15 15:05:59'),
(7, 'New user signed up: TIME ALI RASHID (mrawadhi2005@gmail.com)', 1, '2025-09-15 15:09:03'),
(8, 'New user signed up: TIME ALI RASHID (mrawadhi2005@gmail.com)', 1, '2025-09-15 15:14:40'),
(9, 'New user signed up: gggg ffff (mrawadhi2005@gmail.com)', 1, '2025-09-15 15:15:44'),
(10, 'New user signed up: gggg ffff (mrawadhi2005@gmail.com)', 1, '2025-09-15 15:18:24'),
(11, 'New user signed up: ttt fff (mrawadhi2005@gmail.com)', 1, '2025-09-15 15:19:21'),
(12, 'New user signed up: Aisha Ali Said (user@example.com)', 1, '2025-09-16 11:11:57'),
(13, 'New user signed up: gggg ffff (mrawadhi2005@gmail.com)', 1, '2025-09-16 11:22:02'),
(14, 'New user signed up: gggg ffff (mrawadhi2005@gmail.com)', 1, '2025-09-16 11:35:54'),
(15, 'New user signed up: gggg ffff (mrawadhi2005@gmail.com)', 1, '2025-09-16 11:42:30'),
(16, 'New user signed up: gggg ffff (mrawadhi2005@gmail.com)', 1, '2025-09-16 11:55:18'),
(17, 'New user signed up: gggg ffff (mrawadhi2005@gmail.com)', 1, '2025-09-16 12:00:43'),
(18, 'New appointment booked for pressure on 2025-09-16 at 00:00:00 by patient ID 1.', 1, '2025-09-16 12:47:22'),
(19, 'New user signed up: TIME ALI RASHID (mrawadhi2005@gmail.com)', 0, '2025-09-17 11:06:16');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `department` varchar(100) NOT NULL,
  `appointmentDate` date NOT NULL,
  `appointmentTime` time NOT NULL,
  `status` enum('Pending','Confirmed','Cancelled','Completed') DEFAULT NULL,
  `slot_id` int(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `department_id` int(11) DEFAULT NULL,
  `user_hidden` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `user_id`, `department`, `appointmentDate`, `appointmentTime`, `status`, `slot_id`, `created_at`, `updated_at`, `department_id`, `user_hidden`) VALUES
(3, 1, 'medical doctor', '2025-09-01', '00:30:00', 'Cancelled', 8, '2025-09-01 09:12:04', '2025-09-01 09:44:11', 17, 0),
(4, 1, 'pressure', '2025-09-02', '00:30:00', 'Cancelled', 14, '2025-09-02 09:16:17', '2025-09-03 08:41:07', 16, 0),
(5, 2, 'medical doctor', '2025-09-03', '00:30:00', 'Completed', 20, '2025-09-03 14:43:02', '2025-09-12 12:24:03', 17, 0),
(6, 3, 'medical', '2025-09-16', '00:00:00', 'Cancelled', 35, '2025-09-15 14:36:54', '2025-09-15 14:37:56', 23, 1),
(7, 3, 'pressure', '2025-09-15', '00:00:00', 'Cancelled', 30, '2025-09-15 14:38:15', '2025-09-16 11:14:56', 22, 0),
(8, 1, 'pressure', '2025-09-16', '00:00:00', 'Cancelled', 31, '2025-09-16 12:47:22', '2025-09-16 12:50:09', 22, 0);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(23, 'medical'),
(22, 'pressure');

-- --------------------------------------------------------

--
-- Table structure for table `department_slots`
--

CREATE TABLE `department_slots` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `slot_date` date NOT NULL,
  `slot_time` time NOT NULL,
  `is_booked` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department_slots`
--

INSERT INTO `department_slots` (`id`, `department_id`, `slot_date`, `slot_time`, `is_booked`) VALUES
(30, 22, '2025-09-15', '00:00:00', 1),
(31, 22, '2025-09-16', '00:00:00', 1),
(35, 23, '2025-09-15', '00:00:00', 1),
(36, 23, '2025-09-16', '00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `question`, `answer`, `created_at`) VALUES
(4, 'How do I book an appointment?', 'Login to your account, go to the Book Appointment section, select your preferred department, date, and available time slot, then confirm your appointment.', '2025-06-14 16:39:53'),
(5, 'Can I reschedule my appointment?', 'Yes. Go to My Appointments, and if the status is Pending or Confirmed, you can click Reschedule and choose a new date and time.', '2025-06-14 16:40:27'),
(6, 'How do I cancel an appointment?', 'If your appointment is still Pending, you will see a Cancel button in the My Appointments section. Once cancelled, the appointment cannot be reactivated.', '2025-06-14 16:41:01'),
(7, 'What if I miss my appointment?', 'If you miss an appointment, the system will still mark it as Confirmed and you can reshedulle it again.', '2025-06-14 16:44:16'),
(8, 'How can I make a payment?', 'After booking, go to My Appointments, find the appointment with Pending status, and click Make Payment. Fill in your card or mobile money details to confirm payment.', '2025-06-14 16:44:51'),
(9, 'What happens after I make a payment?', 'Once payment is successful, your appointment status will change to Confirmed, and you\'ll be expected to attend at the scheduled date and time.', '2025-06-14 16:45:26'),
(10, 'Why is my appointment showing “Cancelled”?', 'Appointments can be cancelled manually by the user or automatically by the system if not confirmed within 30 minutes after booking. You’ll need to book again.', '2025-06-14 16:46:05'),
(11, 'How can I view my appointment history?', 'Go to the My Appointments page. All your past and upcoming appointments will be listed there, including status and payment details.', '2025-06-14 16:47:21'),
(12, 'Why can’t I cancel a “Completed” appointment?', 'Once an appointment is marked as Completed by the receptionist, no further actions (like cancellation or rescheduling) can be taken.', '2025-06-14 16:47:57'),
(13, 'Why am I seeing the message “You have already booked an appointment within the last 6 hours. Please wait before booking again”?', 'This message appears when you choose the “Pay Later” option and already have an existing appointment booked within the last 6 hours.\r\nTo ensure fairness and prevent misuse of the Pay Later feature, our system restricts multiple bookings within a 6-hour period under this option.\r\n\r\nIf you want to book another appointment urgently, please:\r\n\r\nWait 6 hours before booking again with Pay Later, or\r\n\r\nUse the Pay Now option to proceed with your next booking.', '2025-06-15 11:48:20');

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `tittle` text NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `tittle`, `message`, `created_at`) VALUES
(12, 'Ziara ya madaktari bingwa', 'siku ya jumatatu kutakuwa na ugeni wa madaktari bingwa katika  ukumbi wa hospitali yetu ,watu wote mnaombwa kuhudhuria', '2025-09-14 21:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `is_read`, `created_at`) VALUES
(0, 0, 'Welcome to MASS! Your account has been successfully created.', 1, '2025-08-31 07:01:07'),
(0, 0, 'Welcome to MASS! Your account has been successfully created.', 1, '2025-08-31 07:04:39'),
(0, 0, 'Welcome to MASS! Your account has been successfully created.', 1, '2025-08-31 07:07:33'),
(0, 0, 'Your appointment for dental on 2025-09-01 at 00:00:00 has been booked.', 0, '2025-09-01 08:44:42'),
(0, 0, 'Your appointment for medical doctor on 2025-09-01 at 00:00:00 has been booked.', 0, '2025-09-01 08:55:04'),
(0, 0, 'Your appointment for dental on 2025-09-01 at 00:00:00 has been rescheduled to 2025-09-02 at 00:30:00.', 0, '2025-09-01 09:01:43'),
(0, 1, 'Your appointment for medical doctor on 2025-09-01 at 00:30:00 has been booked.', 1, '2025-09-01 09:12:04'),
(0, 1, 'Your details have been updated successfully on 2025-09-01 11:38:42.', 1, '2025-09-01 09:38:42'),
(0, 1, 'Your details have been updated successfully on 2025-09-01 11:39:51.', 1, '2025-09-01 09:39:51'),
(0, 1, 'Your appointment for pressure on 2025-09-02 at 00:30:00 has been booked.', 1, '2025-09-02 09:16:17'),
(0, 1, 'Your details have been updated successfully on 2025-09-03 10:41:24.', 1, '2025-09-03 08:41:24'),
(0, 1, 'Your details have been updated successfully on 2025-09-03 10:41:29.', 1, '2025-09-03 08:41:29'),
(0, 1, 'Your details have been updated successfully on 2025-09-03 15:20:33.', 1, '2025-09-03 13:20:33'),
(0, 2, 'Welcome to MASS! Your account has been successfully created.', 1, '2025-09-03 14:41:35'),
(0, 2, 'Your appointment for medical doctor on 2025-09-03 at 00:00:00 has been booked.', 1, '2025-09-03 14:43:02'),
(0, 2, '📢 New Notice posted: rr', 1, '2025-09-12 12:21:14'),
(0, 2, '📢 New Notice posted: matokeo', 1, '2025-09-12 12:22:46'),
(0, 2, 'Your appointment for medical doctor on 2025-09-03 at 00:00:00 has been rescheduled to 2025-09-03 at 00:30:00.', 1, '2025-09-12 12:24:03'),
(0, 2, '📢 New Notice posted: Ufunguzi wa bweni la wanafunzi', 1, '2025-09-12 12:37:22'),
(0, 3, 'Welcome to MASS! Your account has been successfully created.', 1, '2025-09-15 14:30:48'),
(0, 3, 'Your details have been updated successfully on 2025-09-15 16:34:59.', 1, '2025-09-15 14:34:59'),
(0, 3, 'Your appointment for medical on 2025-09-15 at 00:00:00 has been booked.', 1, '2025-09-15 14:36:54'),
(0, 3, 'Your appointment for medical on 2025-09-15 at 00:00:00 has been rescheduled to 2025-09-16 at 00:00:00.', 1, '2025-09-15 14:37:13'),
(0, 3, 'Your appointment for pressure on 2025-09-15 at 00:00:00 has been booked.', 1, '2025-09-15 14:38:15'),
(0, 3, '📢 New Notice posted: tt', 1, '2025-09-15 14:49:17'),
(0, 4, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-15 15:05:59'),
(0, 5, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-15 15:09:03'),
(0, 6, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-15 15:14:40'),
(0, 7, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-15 15:15:44'),
(0, 8, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-15 15:18:24'),
(0, 9, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-15 15:19:21'),
(0, 1, 'Welcome to OPS! Your account has been successfully created.', 1, '2025-09-16 11:11:57'),
(0, 2, 'Welcome to OPS! Your account has been successfully created.', 1, '2025-09-16 11:22:02'),
(0, 3, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-16 11:35:54'),
(0, 4, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-16 11:42:30'),
(0, 5, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-16 11:55:18'),
(0, 6, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-16 12:00:43'),
(0, 1, 'Your appointment for pressure on 2025-09-16 at 00:00:00 has been booked.', 1, '2025-09-16 12:47:22'),
(0, 7, 'Welcome to OPS! Your account has been successfully created.', 0, '2025-09-17 11:06:16');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `dob` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `regno`, `phone`, `gender`, `dob`, `created_at`) VALUES
(6, 'ddd', 'WSS-2025-55254', 555, 'Female', '2025-09-16', '2025-09-15 14:22:17');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `otp` varchar(255) NOT NULL,
  `otp_generated_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_blocked` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `otp`, `otp_generated_time`, `is_read`, `created_at`, `is_blocked`) VALUES
(1, 'Aisha Ali Said', 'user@example.com', '0736754357', '$2y$10$mF1DvAYH/sJKT2xN6b9p9.dj9D9NiHXE0JNUTBTI6zNrtwJQwQ70.', '', '2025-09-16 11:11:57', 0, '2025-09-16 11:11:57', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `department_slots`
--
ALTER TABLE `department_slots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `department_slots`
--
ALTER TABLE `department_slots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
