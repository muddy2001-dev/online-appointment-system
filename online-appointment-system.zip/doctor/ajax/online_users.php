<?php
session_name("admin_session");
session_start();
include_once __DIR__ . '/../database.php';

// Get role and table dynamically
$role = $_GET['role'] ?? 'user';
$table = ($role === 'receptionist') ? 'receptionist' : 'users';

// Delete user/receptionist
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM $table WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: manage_users.php");
    exit;
}

// Block user/receptionist
if (isset($_GET['block'])) {
    $id = intval($_GET['block']);
    $stmt = $conn->prepare("UPDATE $table SET is_blocked = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: manage_users.php");
    exit;
}

// Unblock user/receptionist
if (isset($_GET['unblock'])) {
    $id = intval($_GET['unblock']);
    $stmt = $conn->prepare("UPDATE $table SET is_blocked = 0 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: manage_users.php");
    exit;
}

// Fetch users
$userResult = $conn->query("SELECT id, name, email, phone, is_blocked, 'User' as role FROM users");



// Merge both results
$allUsers = [];
if ($userResult) {
    while ($row = $userResult->fetch_assoc()) {
        $allUsers[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Users</title>
  <style>
    body { font-family: sans-serif; 
        background: #f0f0f0;
         margin: 0; padding: 0; }

    h3 {
        text-align: center;
        margin-bottom: 20px;
    }
    table {
        width: 100%;
        background-color: #fff;
        border-collapse: collapse;
        border-radius: 5px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    th, td {
        padding: 12px 15px;
        text-align: center;
        border-bottom: 1px solid #ccc;
    }
    th {
        background-color: #2c3e50;
        color: white;
    }
    tr:hover {
        background-color: #f1f1f1;
    }
    tr.receptionist {
        background-color: #e0f7fa;
    }
    .action-btn {
        border: none;
        padding: 6px 12px;
        border-radius: 4px;
        cursor: pointer;
        margin-right: 5px;
    }
    .delete-btn { background-color: red; color: white; }
    .delete-btn:hover { background-color: darkred; }
    .block-btn { background-color: orange; color: white; }
    .block-btn:hover { background-color: darkorange; }
    .unblock-btn { background-color: green; color: white; }
    .unblock-btn:hover { background-color: darkgreen; }
  </style>
</head>
<body>


  <h3>Manage Registered Users</h3>

  <table>
    <thead>
      <tr>
        <th>ID</th>
       
        <th>Full name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($allUsers as $row): ?>
        <tr class="<?= $row['role'] === 'Receptionist' ? 'receptionist' : '' ?>">
          <td><?= htmlspecialchars($row['id']) ?></td>
        
          <td><?= htmlspecialchars($row['name']) ?></td>
          <td><?= htmlspecialchars($row['email']) ?></td>
          <td><?= htmlspecialchars($row['phone']) ?></td>
          <td><?= $row['is_blocked'] ? 'Blocked' : 'Active' ?></td>
        <td>
  <button class="action-btn delete-btn user-action" 
          data-action="delete" 
          data-id="<?= $row['id'] ?>" 
          data-role="<?= strtolower($row['role']) ?>">
    Delete
  </button>

  <?php if ($row['is_blocked']): ?>
    <button class="action-btn unblock-btn user-action" 
            data-action="unblock" 
            data-id="<?= $row['id'] ?>" 
            data-role="<?= strtolower($row['role']) ?>">
      Unblock
    </button>
  <?php else: ?>
    <button class="action-btn block-btn user-action" 
            data-action="block" 
            data-id="<?= $row['id'] ?>" 
            data-role="<?= strtolower($row['role']) ?>">
      Block
    </button>
  <?php endif; ?>
</td>

        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

</body>
</html>
