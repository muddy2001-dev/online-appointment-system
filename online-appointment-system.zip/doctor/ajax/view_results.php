<?php
session_start();
include_once __DIR__ . '/../database.php';

// Get filters from query params or default to empty
$selectedClass = $_GET['class'] ?? '';
$selectedSection = $_GET['section'] ?? '';

// Prepare base query with join to students table to filter by class and section
$sql = "
SELECT 
    students.id AS student_id,
    students.name AS student_name,
    students.regno,
    subjects.subject,
    results.marks
FROM results
JOIN students ON results.student_id = students.id
JOIN subjects ON results.subject_id = subjects.id
";

// Add WHERE clauses if filters set
$whereClauses = [];
$params = [];
$paramTypes = '';

if ($selectedClass !== '') {
    $whereClauses[] = "students.class = ?";
    $params[] = $selectedClass;
    $paramTypes .= 's';
}

if ($selectedSection !== '') {
    $whereClauses[] = "students.section = ?";
    $params[] = $selectedSection;
    $paramTypes .= 's';
}

if (count($whereClauses) > 0) {
    $sql .= " WHERE " . implode(" AND ", $whereClauses);
}

$sql .= " ORDER BY students.name, subjects.subject";

// Prepare statement
$stmt = $conn->prepare($sql);
if ($stmt && count($params) > 0) {
    $stmt->bind_param($paramTypes, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$groupedResults = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $studentId = $row['student_id'];
        if (!isset($groupedResults[$studentId])) {
            $groupedResults[$studentId] = [
                'name' => $row['student_name'],
                'regno' => $row['regno'],
                'subjects' => []
            ];
        }
        $groupedResults[$studentId]['subjects'][] = [
            'subject' => $row['subject'],
            'marks' => $row['marks']
        ];
    }
} else {
    $groupedResults = null;
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>View Students Results</title>
  <style>
    /* your styles here */
   
    form { margin-bottom: 25px; }
    label { margin-right: 10px; font-weight: bold; }
    select { margin-right: 20px; padding: 5px 10px; }
    .student {
      margin-bottom: 30px;
      border-bottom: 2px solid #007bff;
      padding-bottom: 15px;
    }
    h3 {
      margin-bottom: 5px;
      color: #007bff;
    }
    table {
      border-collapse: collapse;
      width: 80%;
      margin-top: 10px;
    }
    th, td {
      padding: 8px 12px;
      border: 1px solid #ccc;
      text-align: left;
    }
    th {
      background-color: #0056b3;
      color: white;
    }
  </style>
</head>
<body>
  <h2>View Students Results</h2>

<form id="filterForm" method="GET" action="view_results.php">

    <label for="class">Class:</label>
    <select name="class" id="class" required>
      <option value="">-- Select Class --</option>
      <option value="Form 1" <?= $selectedClass === 'Form 1' ? 'selected' : '' ?>>Form 1</option>
      <option value="Form 2" <?= $selectedClass === 'Form 2' ? 'selected' : '' ?>>Form 2</option>
      <option value="Form 3" <?= $selectedClass === 'Form 3' ? 'selected' : '' ?>>Form 3</option>
      <option value="Form 4" <?= $selectedClass === 'Form 4' ? 'selected' : '' ?>>Form 4</option>
    </select>

    <label for="section">Section:</label>
    <select name="section" id="section" required>
      <option value="">-- Select Section --</option>
      <option value="A" <?= $selectedSection === 'A' ? 'selected' : '' ?>>A</option>
      <option value="B" <?= $selectedSection === 'B' ? 'selected' : '' ?>>B</option>
      <option value="C" <?= $selectedSection === 'C' ? 'selected' : '' ?>>C</option>
    </select>

    <button type="submit">Filter Results</button>
  </form>

  <?php if ($groupedResults): ?>
    <?php foreach ($groupedResults as $student): ?>
      <div class="student">
        <h3><?= htmlspecialchars($student['name']) ?> (Reg#: <?= htmlspecialchars($student['regno']) ?>)</h3>
        <table>
          <thead>
            <tr>
              <th>Subject</th>
              <th>Marks</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($student['subjects'] as $sub): ?>
              <tr>
                <td><?= htmlspecialchars($sub['subject']) ?></td>
                <td><?= htmlspecialchars($sub['marks']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <p>No results found for selected class and section.</p>
  <?php endif; ?>
</body>
</html>
