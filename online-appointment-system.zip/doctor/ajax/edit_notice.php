<?php
include_once '../database.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    echo "<p style='color:red; text-align:center;'>Invalid notice ID.</p>";
    exit;
}

$stmt = $conn->prepare("SELECT * FROM faqs WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<p style='color:red; text-align:center;'>Notice not found.</p>";
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Notice</title>
    <style>
     

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #34495e;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            width: 100%;
        }

        button:hover {
            background-color: #2980b9;
        }

        #editResponse {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Edit Notice</h2>

<form id="editNoticeForm">
    <input type="hidden" name="id" value="<?= $row['id'] ?>">

    <label>Title:</label>
    <input type="text" name="tittle" value="<?= htmlspecialchars($row['tittle']) ?>" required>

    <label>Message:</label>
    <input type="text" name="message" value="<?= htmlspecialchars($row['message']) ?>" required>

    <label>Date:</label>
    <input type="date" name="created_at" value="<?= htmlspecialchars($row['created_at']) ?>" required>

    <button type="submit">Update Notice</button>
    <div id="editResponse"></div>
</form>



<script>
document.getElementById("editNoticeForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch("ajax/update_notice.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        const msg = document.getElementById("editResponse");
        if (data.success) {
            msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
            setTimeout(() => {
                loadPage('manage_notice.php'); // reload notices list
            }, 1000);
        } else if (data.error) {
            msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
        }
    })
    .catch(() => alert("Error updating notice"));
});
</script>

</body>
</html>
