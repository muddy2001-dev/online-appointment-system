<?php
 include_once __DIR__ . '/../database.php';

if (isset($_GET['delete_id'])) {
    $id = (int)$_GET['delete_id'];

    $slot_check = $conn->prepare("SELECT COUNT(*) AS count FROM appointments WHERE department_id = ?");
    $slot_check->bind_param("i", $id);
    $slot_check->execute();
    $slot_result = $slot_check->get_result()->fetch_assoc();

    if ($slot_result['count'] == 0) {
        $conn->query("DELETE FROM department_slots WHERE id = $id");
    } else {
        echo "<script>alert('Cannot delete a slot that already has a booking.');</script>";
    }
}

$slots = $conn->query("
    SELECT department_slots.id, departments.name AS department, slot_date, slot_time
    FROM department_slots
    JOIN departments ON departments.id = department_slots.department_id
    ORDER BY departments.name ASC, slot_date ASC, slot_time ASC
");

$grouped_slots = [];
while ($slot = $slots->fetch_assoc()) {
    $dept = $slot['department'];
    $grouped_slots[$dept][] = $slot;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Appointment Slots</title>
    <style>
        
        body { font-family: sans-serif; 
            background: #f0f0f0; padding: 20px; 
         margin: 0;
            padding: 0;}
            body.dark-mode {
    background-color: #121212;
    color: #f0f0f0;
}



        }

        .container { background: white; padding: 20px; border-radius: 10px; max-width: 1000px; margin: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
        th { background: #e0e0e0; }
        h4 { margin-top: 40px;  background-color: #2c3e50; color: white; padding: 10px; border-radius: 5px; }
        .danger { color: red; text-decoration: none; }
        .back-btn { background: #555; color: white; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer;text-decoration:none; }
        .back-btn:hover { background: #333; }
        .date-header { font-weight: bold; background-color: #f5f5f5; text-align: left; padding: 10px; }
      
    </style>
</head>
<body>
   

<div class="container">
    <h3>Manage Existing Appointment Slots</h3><br>
   
     <a href="javascript:void(0);" class="back-btn" onclick="loadPage('dep.php')">
        ← Back to Department Settings</button></a>
    <br><br>

    <?php foreach ($grouped_slots as $department => $slot_list): ?>
        <h4><?= htmlspecialchars($department) ?> Department</h4>
        <table>
            <tr>
                <th>ID</th>
                <th>Time</th>
                <th>Action</th>
            </tr>
            <?php
                $last_date = '';
                foreach ($slot_list as $slot):
                    $is_new_date = $slot['slot_date'] !== $last_date;
                    if ($is_new_date):
                        echo '<tr><td colspan="3" class="date-header">Date: <strong>' . $slot['slot_date'] . '</strong></td></tr>';
                        $last_date = $slot['slot_date'];
                    endif;
            ?>
            <tr>
                <td><?= $slot['id'] ?></td>
                <td>
    <?php
    $time = $slot['slot_time'];
    $hour = (int)substr($time, 0, 2);
    $suffix = ($hour < 12) ? 'AM' : 'PM';
    echo $time . ' ' . $suffix;
    ?>
</td>

                <td>
                   <a href="javascript:void(0);" 
   class="danger delete-slot" 
   data-id="<?= $slot['id'] ?>">
   Delete
</a>

                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php endforeach; ?>
</div>


</body>
</html>
