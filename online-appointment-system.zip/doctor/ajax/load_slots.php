<?php
require_once '../database.php';

if (empty($_POST['department_id'])) exit;
$department_id = (int)$_POST['department_id'];

// Generate time slots
$timeSlots = [];
$start = strtotime("00:00");
$end   = strtotime("23:30");
while ($start <= $end) {
    $timeSlots[] = date("H:i", $start);
    $start = strtotime("+30 minutes", $start);
}

// Fetch saved slots
$currentSlots = [];
$res = $conn->query("SELECT slot_date, slot_time FROM department_slots WHERE department_id = $department_id");
while ($r = $res->fetch_assoc()) {
    $currentSlots[$r['slot_date']][] = $r['slot_time'];
}
?>

<form id="slotForm">
  <input type="hidden" name="department_id" value="<?= $department_id ?>">
  <input type="hidden" name="set_slots" value="1">

  <table>
      <tr>
          <th>Time / Day</th>
          <?php for ($i=0; $i<7; $i++): 
              $date = date('Y-m-d', strtotime("+$i days"));
              $label = date('D (m-d)', strtotime($date));
          ?>
              <th><?= $label ?><br><small><?= $date ?></small></th>
          <?php endfor; ?>
      </tr>
      <?php foreach ($timeSlots as $time): ?>
      <tr>
          <td><?= $time ?></td>
          <?php for ($i=0; $i<7; $i++):
              $date = date('Y-m-d', strtotime("+$i days"));
              $checked = (isset($currentSlots[$date]) && in_array($time, $currentSlots[$date])) ? 'checked' : '';
          ?>
              <td>
                <input type="checkbox" name="slots[]" value="<?= $date.'|'.$time ?>" <?= $checked ?>>
              </td>
          <?php endfor; ?>
      </tr>
      <?php endforeach; ?>
  </table>

  <button type="submit">Save Slots</button>

  <!-- Move response message here -->
  <div id="slotResponseMessage" style="margin-top:10px;"></div>
</form>


