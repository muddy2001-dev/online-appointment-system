<?php
session_start();
require_once '../database.php';

// ----------------- AJAX HANDLERS -----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    // --- Add Department ---
    if (isset($_POST['add_department'])) {
        $dept = trim($_POST['department_name']);
        if ($dept !== "") {
            $stmt = $conn->prepare("INSERT IGNORE INTO departments (name) VALUES (?)");
            $stmt->bind_param("s", $dept);
            echo $stmt->execute()
                ? json_encode(["success" => "Department added successfully"])
                : json_encode(["error" => "Database error"]);
        } else {
            echo json_encode(["error" => "Department name cannot be empty"]);
        }
        exit;
    }

    // --- Delete Department ---
    if (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        $conn->query("DELETE FROM department_slots WHERE department_id = $id");
        $conn->query("DELETE FROM departments WHERE id = $id");
        echo json_encode(["success" => "Department deleted"]);
        exit;
    }

    // --- Save Slots ---
    if (isset($_POST['set_slots'])) {
        $department_id = (int)$_POST['department_id'];
        $conn->query("DELETE FROM department_slots WHERE department_id = $department_id");

        if (!empty($_POST['slots'])) {
            $stmt = $conn->prepare("INSERT IGNORE INTO department_slots (department_id, slot_date, slot_time) VALUES (?, ?, ?)");
            foreach ($_POST['slots'] as $slot) {
                [$date, $time] = explode('|', $slot);
                $stmt->bind_param("iss", $department_id, $date, $time);
                $stmt->execute();
            }
        }

        echo json_encode(["success" => "Slots saved successfully"]);
        exit;
    }

    echo json_encode(["error" => "Invalid request"]);
    exit;
}

// ----------------- HTML RENDERING -----------------
$departments = $conn->query("SELECT * FROM departments ORDER BY name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Departments</title>
    <style>
      

        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            max-width: 800px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        content: '\f315'; {
            color: #333;
            border-bottom: 2px solid #007BFF;
            padding-bottom: 10px;
        }

        form {
            margin: 20px 0;
        }

        input[type="text"], select {
            padding: 8px;
            width: calc(100% - 16px);
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
             background-color: #2c3e50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align:center;
        }

        table th {
            background-color: #2c3e50;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .deleteDeptBtn {
            background-color: #dc3545;
        }

        .deleteDeptBtn:hover {
            background-color: #c82333;
        }

        #responseMessage, #slotResponseMessage {
            margin-top: 10px;
            color: green;
        }
    </style>
</head>
<body>

<div class="container">
    <h3>Manage Departments</h3>

    <!-- Add Department -->
    <form id="addDeptForm">
        <input type="text" name="department_name" placeholder="New department..." required>
        <input type="hidden" name="add_department" value="1">
        <button type="submit">Add Department</button>
    </form>

    <div id="responseMessage"></div>

    <!-- Departments Table -->
    <table>
        <tr><th>ID</th><th>Name</th><th>Action</th></tr>
        <?php while ($dept = $departments->fetch_assoc()): ?>
            <tr>
                <td><?= $dept['id'] ?></td>
                <td><?= htmlspecialchars($dept['name']) ?></td>
                <td>
                    <button class="deleteDeptBtn" data-id="<?= $dept['id'] ?>">Delete</button>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <!-- Slot Form -->
    <h2>Set Available Slots</h2>

    <div id="slotResponseMessage"></div>

    <form id="slotForm">
        <label>Select Department:</label>
        <select name="department_id" id="departmentSelect" required>
            <option value="">-- Choose Department --</option>
            <?php
            $departments = $conn->query("SELECT * FROM departments ORDER BY name ASC");
            while ($d = $departments->fetch_assoc()):
            ?>
                <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['name']) ?></option>
            <?php endwhile; ?>
        </select>

        <!-- This container should be dynamically filled with slots (date/time pickers) -->
        <div id="slotsContainer"></div>

        <!-- Example submit button if you want it -->
        <!-- <button type="submit">Save Slots</button> -->
    </form>
</div>

<!-- JavaScript (To be written or enhanced by you) -->
<script>
    // Example: handle form submission for Add Department
    document.getElementById('addDeptForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);

        fetch('', {
            method: 'POST',
            body: formData
        }).then(res => res.json())
          .then(data => {
              document.getElementById('responseMessage').textContent = data.success || data.error;
              if (data.success) location.reload(); // refresh to show new dept
          });
    });

    // Example: Delete Department
    document.querySelectorAll('.deleteDeptBtn').forEach(btn => {
        btn.addEventListener('click', function () {
            if (!confirm("Delete this department?")) return;

            const formData = new FormData();
            formData.append('delete_id', this.dataset.id);

            fetch('', {
                method: 'POST',
                body: formData
            }).then(res => res.json())
              .then(data => {
                  alert(data.success || data.error);
                  if (data.success) location.reload();
              });
        });
    });

    // You can build JS logic to handle dynamic slot inputs later
</script>

</body>
</html>
