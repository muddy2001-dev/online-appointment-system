<?php
include_once '../database.php';

$result = $conn->query("SELECT * FROM patients ORDER BY id DESC LIMIT 10");

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Registered Patients</title>
    <style>
      
        h3 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background-color: #2c3e50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e6f7ff;
        }
        .btn-delete {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 6px 12px;
            cursor: pointer;
            border-radius: 4px;
        }
        .btn-delete:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<h3>Registered Patients</h3>";

if ($result) {
    echo "<table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Reg. Number</th>
                <th>Phone</th>
                <th>Gender</th>
                <th>Date Of Birth</th>
                <th>Registration Date</th>
              
            </tr>";

    while ($row = $result->fetch_assoc()) {
        $id = $row['id'];
        echo "<tr>
                <td>{$id}</td>
                <td>{$row['name']}</td>
                <td>{$row['regno']}</td>
                <td>{$row['phone']}</td>
                <td>{$row['gender']}</td>
                <td>{$row['dob']}</td>
                <td>{$row['created_at']}</td>
               
            </tr>";
    }

    echo "</table>";
} else {
    echo "<p>Error retrieving patients: " . $conn->error . "</p>";
}

$conn->close();

echo "</body>
<script>
function deletePatient(id) {
    if (confirm('Are you sure you want to delete this patient?')) {
        fetch('ajax/delete_patient.php?id=' + id, { method: 'GET' })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert(data.success);
                location.reload(); // Reload the page to reflect deletion
            } else if (data.error) {
                alert(data.error);
            }
        })
        .catch(() => alert('Error deleting patient'));
    }
}
</script>
</html>";
?>
