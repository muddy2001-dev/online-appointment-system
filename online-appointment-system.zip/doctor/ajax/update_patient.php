<?php
include_once '../database.php';

$response = [];

$id      = intval($_POST['id'] ?? 0);
$name   = trim($_POST['name'] ?? '');
$regno  = trim($_POST['regno'] ?? '');
$phone   = trim($_POST['phone'] ?? '');
$gender  = trim($_POST['gender'] ?? '');
$dob  = trim($_POST['dob'] ?? '');
$created_at  = trim($_POST['created_at'] ?? '');
;

if ($id <= 0 || empty($name) || empty($regno) || empty($phone) || empty($gender) || empty($dob) || empty($created_at)) {
    $response['error'] = "All fields are required.";
} else {
    $stmt = $conn->prepare("UPDATE patients SET name=?, regno=?, phone=?, gender=?, dob=?, created_at=? WHERE id=?");
    $stmt->bind_param("ssisssi", $name, $regno, $phone, $gender, $dob, $created_at, $id);

    if ($stmt->execute()) {
        $response['success'] = "Patient updated successfully.";
    } else {
        $response['error'] = "Failed to update Patient.";
    }
    $stmt->close();
}

$conn->close();
echo json_encode($response);
?>
