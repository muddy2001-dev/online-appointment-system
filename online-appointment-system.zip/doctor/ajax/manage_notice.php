<?php
include_once '../database.php';

$result = $conn->query("SELECT * FROM faqs ORDER BY id DESC LIMIT 10");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Users Notices</title>
    <style>
      

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        table {
            width: 90%;
            margin: 0 auto 30px auto;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
        }

        th {
            background-color: #2c3e50;
            color: #fff;
            text-transform: uppercase;
            font-size: 14px;
        }

        tr {
            background-color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #d6eaf8;
        }

        .action-btn {
            padding: 5px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .edit-btn {
            background-color: #2ecc71;
            color: white;
            margin-right: 5px;
        }

        .delete-btn {
            background-color: #e74c3c;
            color: white;
        }

        @media (max-width: 768px) {
            table, th, td {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>

<h2>Users Notices</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Message</th>
        <th>Date Created</th>
        <th>Actions</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['tittle']) ?></td>
        <td><?= htmlspecialchars($row['message']) ?></td>
        <td><?= htmlspecialchars($row['created_at']) ?></td>
        <td>
            <button class="action-btn edit-btn" data-id="<?= $row['id'] ?>">Edit</button>
            <button class="action-btn delete-btn" data-id="<?= $row['id'] ?>">Delete</button>

        </td>
    </tr>
    <?php endwhile; ?>
</table>

<script>
function deleteNotice(id) {
    if (confirm("Are you sure you want to delete this notice?")) {
        fetch('ajax/delete_notice.php?id=' + id, { method: 'GET' })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert(data.success);
                location.reload(); // reload page after deletion
            } else if (data.error) {
                alert(data.error);
            }
        })
        .catch(() => alert("Error deleting notice"));
    }
}
</script>

</body>
</html>

<?php $conn->close(); ?>
