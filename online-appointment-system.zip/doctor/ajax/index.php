<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ajax Sidebar Layout</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>



   <!-- Content -->
    <div class="content" id="mainContent">
     <h3>Welcome to Your Dashboard</h3>

  <div class="dashboard-cards">

  <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_users.php')">
    <div class="card">
      <div class="card-logo">👁️</div>
      <strong>Today's Appointments</strong>
    </div>
  </a>

  <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_patients.php')">
    <div class="card">
      <div class="card-logo">👨‍⚕️</div>
      <strong>Walk-In Patients </strong>
    </div>
  </a>

   <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_slots.php')">
    <div class="card">
      <div class="card-logo">📋</div>
      <strong>Available slots</strong>
    </div>
  </a>

  <a href="javascript:void(0);" class="card-link" onclick="loadPage('users.php')">
    <div class="card">
      <div class="card-logo">💳</div>
      <strong>Online Registered Users</strong>
    </div>
  </a>

</div>

<script src="ajax/assets/ajax-forms.js"></script>


</body>
</html>
