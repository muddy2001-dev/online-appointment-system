<?php
include_once __DIR__ . '/../database.php';

$class = $_GET['class'] ?? '';
$section = $_GET['section'] ?? '';

$class = trim($class);
$section = trim($section);

header('Content-Type: application/json');

if (!$class || !$section) {
    echo json_encode([]);
    exit;
}

$stmt = $conn->prepare("SELECT id, name, regno FROM students WHERE class = ? AND section = ?");
$stmt->bind_param("ss", $class, $section);
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($students);
