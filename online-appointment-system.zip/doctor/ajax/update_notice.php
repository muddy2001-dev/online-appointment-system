<?php
include_once '../database.php';

$response = [];

$id      = intval($_POST['id'] ?? 0);
$tittle   = trim($_POST['tittle'] ?? '');
$message  = trim($_POST['message'] ?? '');
$created_at  = trim($_POST['created_at'] ?? '');
;

if ($id <= 0 || empty($tittle) || empty($message)|| empty($created_at)){
    $response['error'] = "All fields are required.";
} else {
    $stmt = $conn->prepare("UPDATE faqs SET tittle=?, message=?, created_at=? WHERE id=?");
    $stmt->bind_param("sssi", $tittle, $message, $created_at, $id);

    if ($stmt->execute()) {
        $response['success'] = "Notice updated successfully.";
    } else {
        $response['error'] = "Failed to update notice.";
    }
    $stmt->close();
}

$conn->close();
echo json_encode($response);
?>
