<?php
session_start();

include_once __DIR__ . '/../database.php';

// Handle search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Prepare SQL with optional search filter
$sql = "SELECT a.*, u.name AS patient_name 
        FROM appointments a 
        JOIN users u ON a.user_id = u.id";

if ($search !== '') {
    $searchTerm = "%{$search}%";
    $sql .= " WHERE 
                u.name LIKE ? OR 
                a.department LIKE ? OR 
                a.status LIKE ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql .= " ORDER BY a.appointmentDate DESC, a.appointmentTime DESC";
    $result = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Receptionist - Appointments</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        h3 {
            text-align: center;
            margin: 30px 0 10px;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ccc;
        }
        .badge {
            padding: 5px 10px;
            color: #fff;
            border-radius: 5px;
        }
        .badge.pending { background-color: orange; }
        .badge.confirmed { background-color: green; }
        .badge.completed { background-color: blue; }
        .badge.cancelled { background-color: red; }
        button {
            padding: 6px 10px;
            background: #007bff;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        form.search-form {
            text-align: center;
            margin: 10px 0 20px;
        }
        input[type="text"] {
            padding: 8px 12px;
            width: 280px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            padding: 8px 15px;
            font-size: 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            margin-left: 8px;
        }
    </style>
</head>
<body>




<h3>All Appointments</h3>

<!-- 🔍 Search form -->
<form class="search-form" method="GET" action="">
    <input type="text" name="search" placeholder="Search by patient, department, or status..." value="<?= htmlspecialchars($search) ?>">
    <input type="submit" value="Search">
</form>

<?php if ($result->num_rows > 0): ?>
<table>
    <thead>
        <tr>
            <th>Patient name</th>
            <th>Department</th>
            <th>Date</th>
            <th>Time</th>
            <th>Status</th>
            <th>Mark as Completed</th>
        </tr>
    </thead>
    <tbody>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr data-id="<?= $row['id'] ?>">
            <td><?= htmlspecialchars($row['patient_name']) ?></td>
            <td><?= htmlspecialchars($row['department']) ?></td>
            <td><?= htmlspecialchars($row['appointmentDate']) ?></td>
            <td><?= htmlspecialchars($row['appointmentTime']) ?></td>
            <td><span class="badge <?= strtolower($row['status']) ?>"><?= htmlspecialchars($row['status']) ?></span></td>
            <td>
                <?php if ($row['status'] === 'Pending'): ?>
                    <button class="complete-btn" data-id="<?= $row['id'] ?>">✅ Complete</button>
                <?php elseif ($row['status'] === 'Completed'): ?>
                    ✅ Done
                <?php elseif ($row['status'] === 'Cancelled'): ?>
                    ❌ Cancelled
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<!-- 🔥 AJAX Script -->
<script>
document.querySelectorAll('.complete-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        const id = this.getAttribute('data-id');
        if (!confirm('Mark as completed?')) return;

        fetch('mark_completed.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'appointment_id=' + encodeURIComponent(id)
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                const row = this.closest('tr');
                const badge = row.querySelector('.badge');
                badge.className = 'badge completed';
                badge.textContent = 'Completed';
                this.outerHTML = '✅ Done';
            } else {
                alert(data.error || 'Failed to update');
            }
        })
        .catch(() => alert('Error updating status'));
    });
});
</script>
<?php else: ?>
    <p style="text-align:center;">No appointments found.</p>
<?php endif; ?>


</body>
</html>
