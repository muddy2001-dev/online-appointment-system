<?php
include_once __DIR__ . '/../database.php';
session_name("admin_session");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['admin_id'];


$fullName = $email = $phone = "";

// Fetch user data
$stmt = $conn->prepare("SELECT fullName, email, phone FROM admin WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $fullName = $user['fullName'];
    $email = $user['email'];
    $phone = $user['phone'];
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        

        .container {
            max-width: 450px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        content: '\f315'; {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: 500;
        }

        input[type="text"], input[type="email"], input[type="tel"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            margin-top: 5px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
        }

        input[readonly] {
            background-color: #e9ecef;
            cursor: not-allowed;
        }

     
    </style>
</head>
<body>


    <div class="container">
        <h2>My Details</h2>

        <label>Full Name</label>
        <input type="text" value="<?= htmlspecialchars($fullName) ?>" readonly>

        <label>Email</label>
        <input type="email" value="<?= htmlspecialchars($email) ?>" readonly>

        <label>Phone</label>
        <input type="tel" value="<?= htmlspecialchars($phone) ?>" readonly>
    </div>
</body>
</html>
