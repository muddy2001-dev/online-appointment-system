<?php
session_name("admin_session");
session_start();
include_once __DIR__ . '/../database.php';

if (!isset($_SESSION['admin_id'])) {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        echo json_encode(['error' => 'Please login first.']);
        exit();
    }
    // If normal page load, just render HTML later
}

$admin_id = $_SESSION['admin_id'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json'); // important!

    $currentPassword = trim($_POST['current_password'] ?? '');
    $newPassword     = trim($_POST['new_password'] ?? '');
    $retypePassword  = trim($_POST['retype_password'] ?? '');

    $stmt = $conn->prepare("SELECT password FROM admin WHERE id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $admin = $res->fetch_assoc();
    $stmt->close();

    if (!$admin || !password_verify($currentPassword, $admin['password'])) {
        echo json_encode(['error'=>'Incorrect current password.']);
        exit();
    }

    // If new password not provided yet, tell frontend to show fields
    if (empty($newPassword) && empty($retypePassword)) {
        echo json_encode(['show_new'=>true]);
        exit();
    }

    if (strlen($newPassword) < 6) {
        echo json_encode(['error'=>'New password must be at least 6 characters.']);
        exit();
    }
    if ($newPassword !== $retypePassword) {
        echo json_encode(['error'=>'Passwords do not match.']);
        exit();
    }

    $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
    $upd = $conn->prepare("UPDATE admin SET password=? WHERE id=?");
    $upd->bind_param("si", $hashed, $admin_id);

    if ($upd->execute()) {
        echo json_encode(['success'=>'Password updated successfully.']);
    } else {
        echo json_encode(['error'=>'Failed to update password.']);
    }
    $upd->close();
    $conn->close();
    exit();
}

// If not POST → show normal HTML page
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Change Password</title>
<style>
form { max-width:400px; margin:40px auto; background:#fff; padding:30px; border-radius:10px; box-shadow:0 4px 10px rgba(0,0,0,0.1);}
label { display:block; margin:12px 0 6px; font-weight:500; }
input[type=password] { width:100%; padding:10px; border-radius:5px; border:1px solid #ccc; margin-bottom:5px; }
input[type=submit] { background-color:#2c3e50; color:#fff; padding:10px 20px; border:none; border-radius:4px; cursor:pointer; margin-top:7px; }
.error { color:red; font-size:14px; margin-bottom:5px; }
</style>
</head>
<body>
<div class="form-container">
<form id="changePasswordForm">
<h2>Change Password</h2>

<label>Current Password</label>
<input type="password" name="current_password" required>

<div id="newPasswordFields" style="display:none;">
    <label>New Password</label>
    <input type="password" name="new_password" placeholder="Enter new password">

    <label>Retype New Password</label>
    <input type="password" name="retype_password" placeholder="Retype new password">
</div>

<input type="submit" value="Verify Current Password">
<div id="responseMessage"></div>
</form>
</div>

<script>
const form = document.getElementById('changePasswordForm');
const newFields = document.getElementById('newPasswordFields');
const responseDiv = document.getElementById('responseMessage');

form.addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(form);

    fetch('ajax/change_password.php', {   // adjust path if needed
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.show_new) {
            newFields.style.display = 'block';
            form.querySelector('input[type=submit]').value = 'Update Password';
        } else if (data.success) {
            responseDiv.innerHTML = `<div style="color:green;">${data.success}</div>`;
            form.reset();
            newFields.style.display = 'none';
            form.querySelector('input[type=submit]').value = 'Verify Current Password';
        } else if (data.error) {
            responseDiv.innerHTML = `<div style="color:red;">${data.error}</div>`;
        }
    })
    .catch(err => {
        console.error(err);
        alert('Failed to submit form');
    });
});
</script>
</body>
</html>
