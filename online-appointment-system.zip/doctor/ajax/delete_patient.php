<?php
include_once '../database.php';

$id = intval($_GET['id']);
$response = [];

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM patients WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $response['success'] = "Patient deleted successfully.";
    } else {
        $response['error'] = "Failed to delete Patient.";
    }
    $stmt->close();
} else {
    $response['error'] = "Invalid student ID.";
}

$conn->close();
echo json_encode($response);
?>
