<?php
session_name("admin_session");
session_start();
$errors = ['email' => '', 'password' => ''];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'database.php';

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Enter a valid email.";
    }

    if (empty($errors['email'])) {
        // Use admins table
        $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 1) {
            $admin = $res->fetch_assoc();
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin'] = $admin;
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['email'] = $admin['email'];

                header("Location: admin.php");
                exit();
            } else {
                $errors['password'] = "Incorrect password.";
            }
        } else {
            $errors['email'] = "No admin account found with that email.";
        }

        $stmt->close();
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - MASS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* ... same CSS as before ... */
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f2f5f7;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #007bff;
            color: white;
            display: flex;
            justify-content: space-between;
            padding: 5px 10px;
            align-items: center;
        }
        .navbar .logo { font-size: 20px; font-weight: bold; }
        .navbar .nav-links a {
            color: white;
            margin-left: 15px;
            text-decoration: none;
        }
        .form-container {
            max-width: 400px;
            background: white;
            padding: 30px;
            margin: 40px auto;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .login-form h2 { text-align: center; margin-bottom: 25px; color: #333; }
        label { display: block; margin: 12px 0 6px; font-weight: 500; }
        input[type="email"], input[type="password"] {
            width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #ccc;
        }
        .error {
            color: red; font-size: 14px; margin-top: 5px; margin-bottom: -5px;
        }
        button {
            margin-top: 20px; width: 100%; padding: 12px;
            background-color: #007bff; color: white; border: none;
            font-size: 16px; border-radius: 5px; cursor: pointer;
        }
        button:hover { background-color: #0056b3; }
        .forgot-password { margin-top: 15px; text-align: right; }
        .forgot-password a {
            color: #007bff; text-decoration: none;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">+ MASS Admin</div>
        <div class="nav-links">
           
             <button onclick="window.location.href='admin_signup.php'" style="border-radius: 10px; padding: 8px 16px; background-color: white; color: black; border: none; cursor: pointer;">
  Sign Up
   </button>
        </div>
    </nav>

    <div class="form-container">
        <form method="POST" class="login-form">
            <h2>Admin Login</h2>

            <label>Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            <p class="error"><?= $errors['email'] ?></p>

            <label>Password</label>
            <input type="password" name="password" required>
            <p class="error"><?= $errors['password'] ?></p>

            <button type="submit">Login</button>

            <div class="forgot-password">
                <a href="forgot-admin-password.php">Forgot Password?</a>
            </div>
        </form>
    </div>
</body>
</html>
