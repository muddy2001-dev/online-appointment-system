<?php
include_once '../database.php';

$id = intval($_GET['id']);
$response = [];

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM department_slots WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $response['success'] = "Slot deleted successfully.";
    } else {
        $response['error'] = "Failed to delete slot.";
    }
    $stmt->close();
} else {
    $response['error'] = "Invalid slot ID.";
}

$conn->close();
echo json_encode($response);
