
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>View Users</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      margin: 0;
      padding: 0;

    }

    .container {
      max-width: 1250px;
      margin: 0px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    h3 {
      text-align: center;
      color: #333;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    th, td {
      padding: 12px;
      border: 1px solid #ccc;
      text-align: center;
    }

    th {
     background-color: #2c3e50;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    .error {
      color: red;
      text-align: center;
    }

    form {
      text-align: center;
      margin-bottom: 20px;
    }

    input[type="text"] {
      padding: 8px;
      width: 250px;
    }

    button {
      padding: 8px 12px;
      cursor: pointer;
    }


  </style>
</head>
<body>

 

  <div class="container">
    <h3>Registered Users</h3>

    <!-- 🔍 Search form -->
    <form method="GET" action="">
      <input type="text" name="search" placeholder="Search by name, email or phone" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>" />
      <button type="submit">Search</button>
    </form>

    <?php
    include_once __DIR__ . '/../database.php';

    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    if (!empty($search)) {
      $searchEscaped = $conn->real_escape_string($search);
      $sql = "SELECT id, name, email, phone, created_at 
              FROM users 
              WHERE name LIKE '%$searchEscaped%' 
                 OR email LIKE '%$searchEscaped%' 
                 OR phone LIKE '%$searchEscaped%' 
              ORDER BY id DESC";
    } else {
      $sql = "SELECT id, name, email, phone, created_at 
              FROM users 
              ORDER BY id DESC";
    }

    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
      echo "<table>
              <tr>
                <th>ID</th>
                <th>Full name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Signup Date</th>
              </tr>";
      while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['id']) . "</td>
                <td>" . htmlspecialchars($row['name']) . "</td>
                <td>" . htmlspecialchars($row['email']) . "</td>
                <td>" . htmlspecialchars($row['phone']) . "</td>
                <td>" . htmlspecialchars(date("d M Y H:i", strtotime($row['created_at']))) . "</td>
              </tr>";
      }
      echo "</table>";
    } else {
      echo "<p class='error'>No users found.</p>";
    }

    $conn->close();
    ?>
  </div>


</body>
</html>
