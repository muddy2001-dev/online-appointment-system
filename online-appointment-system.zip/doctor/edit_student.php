<?php
include_once '../database.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    echo "<p>Invalid student ID.</p>";
    exit;
}

$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<p>Student not found.</p>";
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<h2>Edit Student</h2>
<form id="editStudentForm">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

    <label>Name:</label><br>
    <input type="text" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required><br><br>

    <label>Reg. Number:</label><br>
    <input type="text" name="regno" value="<?php echo htmlspecialchars($row['regno']); ?>" required><br><br>

    <label>Phone:</label><br>
    <input type="text" name="phone" value="<?php echo htmlspecialchars($row['phone']); ?>" required><br><br>

    <label>Gender:</label><br>
    <select name="gender" required>
        <option value="Male" <?php if ($row['gender'] === 'Male') echo 'selected'; ?>>Male</option>
        <option value="Female" <?php if ($row['gender'] === 'Female') echo 'selected'; ?>>Female</option>
    </select><br><br>

    <label>Class:</label><br>
    <input type="text" name="class" value="<?php echo htmlspecialchars($row['class']); ?>" required><br><br>

    <label>Section:</label><br>
    <input type="text" name="section" value="<?php echo htmlspecialchars($row['section']); ?>" required><br><br>

    <label>Date of Birth:</label><br>
    <input type="date" name="dob" value="<?php echo $row['dob']; ?>" required><br><br>

    <button type="submit">Update Student</button>
</form>

<div id="editResponse"></div>

<script>
document.getElementById("editStudentForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch("ajax/update_student.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        const msg = document.getElementById("editResponse");
        if (data.success) {
            msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
            setTimeout(() => {
                loadPage('view_students.php'); // reload students list
            }, 1000);
        } else if (data.error) {
            msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
        }
    })
    .catch(() => alert("Error updating student"));
});
</script>
