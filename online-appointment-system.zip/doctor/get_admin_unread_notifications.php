<?php
session_name("admin_session");
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(["count" => 0]);
    exit;
}

require 'db.php'; // your DB connection

$admin_id = $_SESSION['admin_id'];

// Example query: count unread notifications for admin
$sql = "SELECT COUNT(*) as cnt FROM admin_notifications WHERE admin_id = ? AND is_read = 0";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

echo json_encode(["count" => (int)$result['cnt']]);
