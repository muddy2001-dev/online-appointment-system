<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_name("admin_session");
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include_once 'database.php';

// Fetch all notifications (no admin_id filter)
$result = $conn->query("SELECT * FROM admin_notifications ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Notifications</title>
  <style>
    body { font-family: sans-serif; background: #f0f0f0; margin: 0; padding: 20px; }
    .navbar { position: fixed; top: 0; left: 0; right: 0;
              background-color: #007bff; color: white;
              display: flex; justify-content: space-between;
              padding: 5px 10px; align-items: center; 
              box-shadow: 0 2px 6px rgba(0,0,0,0.2);}
    .navbar .logo { font-size: 22px; font-weight: bold; }
    .nav-links { display: flex; gap: 15px; }
    h3 { margin-top: 80px; color: #444; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
    .notification { background: #fff; border-left: 5px solid #28a745;
                    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
                    margin-bottom: 15px; padding: 15px 20px;
                    border-radius: 5px; }
    .notification:hover { background: #e9ffe9; }
    .message { font-weight: 600; font-size: 16px; }
    .date { color: #888; font-size: 13px; margin-top: 5px; font-style: italic; }
    .empty { text-align: center; color: #666; margin-top: 50px; font-style: italic; }
  </style>
</head>
<body>
  <nav class="navbar">
    <div class="logo">OPS</div>
    <div class="nav-links">
      <button onclick="window.location.href='index.php'" 
        style="border-radius: 10px; padding: 8px 16px; background-color: white; color: black; border: none; cursor: pointer;">
        Home
      </button>
    </div>
  </nav>

  <h3>Admin Notifications</h3>

  <?php
  if ($result->num_rows === 0) {
      echo '<div class="empty">No notifications yet.</div>';
  } else {
      while ($row = $result->fetch_assoc()) {
          echo '<div class="notification">';
          echo '<div class="message">' . htmlspecialchars($row['message']) . '</div>';
          echo '<div class="date">Received on ' . date('F j, Y, g:i a', strtotime($row['created_at'])) . '</div>';
          echo '</div>';
      }
  }

  // ✅ Mark all as read AFTER showing
  $conn->query("UPDATE admin_notifications SET is_read = 1 WHERE is_read = 0");

  $conn->close();
  ?>
</body>
</html>
