<?php
include_once '../database.php';

$response = [];

$id      = intval($_POST['id'] ?? 0);
$name    = trim($_POST['name'] ?? '');
$regno   = trim($_POST['regno'] ?? '');
$phone   = trim($_POST['phone'] ?? '');
$gender  = trim($_POST['gender'] ?? '');
$class   = trim($_POST['class'] ?? '');
$section = trim($_POST['section'] ?? '');
$dob     = trim($_POST['dob'] ?? '');

if ($id <= 0 || empty($name) || empty($regno) || empty($phone) || empty($gender) || empty($class) || empty($section) || empty($dob)) {
    $response['error'] = "All fields are required.";
} else {
    $stmt = $conn->prepare("UPDATE students SET name=?, regno=?, phone=?, gender=?, class=?, section=?, dob=? WHERE id=?");
    $stmt->bind_param("sssssssi", $name, $regno, $phone, $gender, $class, $section, $dob, $id);

    if ($stmt->execute()) {
        $response['success'] = "Student updated successfully.";
    } else {
        $response['error'] = "Failed to update student.";
    }
    $stmt->close();
}

$conn->close();
echo json_encode($response);
?>
