<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ajax Sidebar Layout</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

  <!-- Header -->
  <div class="header">
    <?php include_once 'header.php'; ?>
  </div>

  <!-- Sidebar + Content Layout -->
  <div class="main-layout">
    <!-- Sidebar -->
    <div class="sidebar">
      <h2><i class="fas fa-bars"></i> Menu</h2>
      <ul>
        
        <!-- Student Classes Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionClasses')"><i class="fas fa-school"></i> Appointments</a>
          <ul class="accordion-content" id="accordionClasses">
            <li><a href="#" onclick="loadPage('view_users.php')">Upcoming Appointments</a></li>
            <li><a href="#" onclick="loadPage('manage_app.php')">Manage Appointments </a></li>

            
          </ul>
        </li>

        <!-- Subjects Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionSubjects')"><i class="fas fa-book"></i> Patients</a>
          <ul class="accordion-content" id="accordionSubjects">
            <li><a href="#" onclick="loadPage('patient.php')">Register New Patient</a></li>
            <li><a href="#" onclick="loadPage('manage_patient.php')">Manage Patients</a></li>
             <li><a href="#" onclick="loadPage('online_users.php')">Manage Users</a></li>
          </ul>
        </li>
           <!-- Results Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionResults')"><i class="fas fa-book"></i>Time Slots</a>
          <ul class="accordion-content" id="accordionResults">
            <li><a href="#" onclick="loadPage('dep.php')">Set Available Slots</a></li>
            <li><a href="#" onclick="loadPage('manage_slots.php')">Manage Slots</a></li>
          </ul>
        </li>
          <!-- Notices Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionNotices')"><i class="fas fa-book"></i> Notices</a>
          <ul class="accordion-content" id="accordionNotices">
            <li><a href="#" onclick="loadPage('faq.php')">Add Notice</a></li>
            <li><a href="#" onclick="loadPage('manage_notice.php')">Manage Notices</a></li>
          </ul>
        </li>

        <!-- Direct Links -->
        <li><a href="#" onclick="loadPage('update.php')"><i class="fas fa-info-circle"></i> Settings</a></li>
         <li><a href="#" onclick="loadPage('index.php')"><i class="fas fa-info-circle"></i> Home</a></li>
      </ul>
    </div>

    <!-- Content -->
    <div class="content" id="mainContent">
     <h3>Welcome to Your Dashboard</h3>

  <div class="dashboard-cards">

  <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_users.php')">
    <div class="card">
      <div class="card-logo">👁️</div>
      <strong>Today's Appointments</strong>
    </div>
  </a>

  <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_patients.php')">
    <div class="card">
      <div class="card-logo">👨‍⚕️</div>
      <strong>Walk-in Patients</strong>
    </div>
  </a>

  <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_slots.php')">
    <div class="card">
      <div class="card-logo">📋</div>
      <strong>Available slots</strong>
    </div>
  </a>

 <a href="javascript:void(0);" class="card-link" onclick="loadPage('users.php')">
    <div class="card">
      <div class="card-logo">💳</div>
      <strong>Online Registered Users</strong>
    </div>
  </a>

</div>


 


<script>
// Load any page via AJAX
function loadPage(page) {
  fetch("ajax/" + page)
    .then(res => res.text())
    .then(html => {
      const mainContent = document.getElementById("mainContent");
      mainContent.innerHTML = html;

if (page === 'view_slots.php') {
  document.querySelectorAll('.delete-slot-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const id = this.getAttribute('data-id');
      if (!id) return;

      if (confirm('Are you sure you want to delete this slot?')) {
        fetch(`ajax/delete_slot.php?id=${id}`, { method: 'GET' })
          .then(res => res.json())
          .then(data => {
            if (data.success) {
              alert(data.success);
              loadPage('view_slots.php'); // reload after deletion
            } else {
              alert(data.error || 'Failed to delete slot');
            }
          })
          .catch(() => alert("Error deleting slot"));
      }
    });
  });
}

// Handle notifictions.php page
if (page === 'notifictions.php') {
  console.log("Notifications page loaded via AJAX");

  // Example: attach delete or mark-read events
  document.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', function() {
      alert("Clicked: " + this.querySelector('.msg').innerText);
      // Optional: add AJAX call here to mark notification as read
    });
  });
}


//Attach AJAX form handler based on the page
        //( number 2 ) Attach AJAX form handler based on the page
      if(page === 'patient.php') {
        const form = document.getElementById('faqForm');
        if(form) {
          form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('ajax/patient.php', {
              method: 'POST',
              body: formData
            })
            .then(res => res.json())
            .then(data => {
              const responseDiv = document.getElementById('responseMessage');
              if(data.success) {
                responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
                form.reset();
              } else if(data.error) {
                responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
              }
            })
            .catch(() => alert('Failed to submit form'));
          });
        }
      }
      

 // (number 14) for updating data
      if (page === 'update.php') {
  const form = document.getElementById('updateForm');
  if (form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(form);

      fetch('ajax/update.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        const messageDiv = document.querySelector('.message');
        if (data.success) {
          messageDiv.innerHTML = `<strong style="color:green;">${data.success}</strong>`;
        } else if (data.error) {
          messageDiv.innerHTML = `<strong style="color:red;">${data.error}</strong>`;
        }
      })
      .catch(() => alert('Failed to update details'));
    });
  }
}


// Manage online users (delete / block / unblock)
if (page === 'online_users.php') {
  document.querySelectorAll('.user-action').forEach(btn => {
    btn.addEventListener('click', function() {
      const id = this.getAttribute('data-id');
      const role = this.getAttribute('data-role');
      const action = this.getAttribute('data-action');

      if (action === 'delete' && !confirm('Are you sure you want to delete this user?')) {
        return;
      }
      if (action === 'block' && !confirm('Are you sure you want to block this user?')) {
        return;
      }

      fetch(`ajax/online_users.php?${action}=${id}&role=${role}`, { method: 'GET' })
        .then(res => res.text())
        .then(() => {
          // Reload table after action
          loadPage('online_users.php');
        })
        .catch(() => alert('Action failed! Please try again.'));
    });
  });
}


// (number Y) Delete slot in manage_slots.php
if (page.startsWith('manage_slots.php')) {
    document.querySelectorAll('.delete-slot').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            if (!confirm('Are you sure you want to delete this slot?')) return;

            fetch('ajax/manage_slots.php?delete_id=' + id)
                .then(res => res.text())
                .then(html => {
                    document.getElementById("mainContent").innerHTML = html;
                })
                .catch(err => alert('Error deleting slot: ' + err));
        });
    });
}

// (number X) Handle Complete Appointment
if (page.startsWith('manage_app.php')) {
    document.querySelectorAll('.complete-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            if (!confirm('Mark as completed?')) return;

            fetch('ajax/mark_completed.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'appointment_id=' + encodeURIComponent(id)
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    // Update row instantly
                    const row = this.closest('tr');
                    row.querySelector('.badge').className = 'badge completed';
                    row.querySelector('.badge').textContent = 'Completed';
                    this.outerHTML = '✅ Done';
                } else {
                    alert(data.error || 'Failed to update');
                }
            })
            .catch(() => alert('Error updating status'));
        });
    });
}


// (number Z) Search in manage_app.php
if (page.startsWith('manage_app.php')) {
    const form = document.querySelector('form.search-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault(); // stop full reload

            const formData = new FormData(form);
            const query = new URLSearchParams(formData).toString();

            // Reload appointments with search filter
            loadPage('manage_app.php?' + query);
        });
    }
}


// (number X) Search users in users.php
if (page.startsWith('users.php')) {
    const form = document.querySelector('form[action=""]'); // your search form
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault(); // prevent full reload

            const formData = new FormData(form);
            const query = new URLSearchParams(formData).toString();

            // reload users.php with search query inside mainContent
            loadPage('users.php?' + query);
        });
    }
}

// (number Y) Search in view_users.php
if (page.startsWith('view_users.php')) {
    const form = document.querySelector('form[action=""]'); // search form
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault(); // stop full reload

            const formData = new FormData(form);
            const query = new URLSearchParams(formData).toString();

            // reload with filtered results via AJAX
            loadPage('view_users.php?' + query);
        });
    }
}


// (number X) Department/date filter in view_slots.php
if (page.startsWith('view_slots.php')) {
    const form = document.getElementById('filterForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault(); // prevent full reload

            const formData = new FormData(form);
            const query = new URLSearchParams(formData).toString();

            // reload the page content with filters
            loadPage('view_slots.php?' + query);
        });
    }
}


//( number 3 ) change password
      if(page === 'change_password.php') {
    const form = document.getElementById('changePasswordForm');
    const newFields = document.getElementById('newPasswordFields');

    if(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('ajax/change_password.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const responseDiv = document.getElementById('responseMessage');
                if(data.show_new){
                    newFields.style.display = 'block';
                    responseDiv.innerHTML = '';
                    form.querySelector('input[type=submit]').value = 'Update Password';
                } else if(data.success){
                    responseDiv.innerHTML = `<div style="color:green;">${data.success}</div>`;
                    form.reset();
                    newFields.style.display = 'none';
                    form.querySelector('input[type=submit]').value = 'Verify Current Password';
                } else if(data.error){
                    responseDiv.innerHTML = `<div style="color:red;">${data.error}</div>`;
                }
            })
            .catch(() => alert('Failed to submit form'));
        });
    }
}

      //( number 1 ) manage notice
      if(page === 'faq.php') {
        const form = document.getElementById('faqForm');
        if(form) {
          form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('ajax/faq.php', {
              method: 'POST',
              body: formData
            })
            .then(res => res.json())
            .then(data => {
              const responseDiv = document.getElementById('responseMessage');
              if(data.success) {
                responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
                form.reset();
              } else if(data.error) {
                responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
              }
            })
            .catch(() => alert('Failed to submit form'));
          });
        }
      }


        //( number 6 ) edit and delete action in notice
      if (page.startsWith('edit_notice.php')) {
    const form = document.getElementById('editNoticeForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('ajax/update_notice.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const msg = document.getElementById('editResponse');
                if (data.success) {
                    msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
                    setTimeout(() => loadPage('manage_notice.php'), 800);
                } else if (data.error) {
                    msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
                }
            })
            .catch(() => alert('Error updating student'));
        });
    }
}

if (page === 'manage_notice.php') {
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete this notice?')) {
                const id = this.getAttribute('data-id');
                fetch(`ajax/delete_notice.php?id=${id}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            loadPage('manage_notice.php');
                        } else {
                            alert(data.error || 'Failed to delete notice');
                        }
                    });
            }
        });
    });

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            loadPage(`edit_notice.php?id=${id}`);
        });
    });
}

      
       //( number 6 ) edit and delete action in patients
      if (page.startsWith('edit_patient.php')) {
    const form = document.getElementById('editPatientForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('ajax/update_patient.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const msg = document.getElementById('editResponse');
                if (data.success) {
                    msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
                    setTimeout(() => loadPage('manage_patient.php'), 800);
                } else if (data.error) {
                    msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
                }
            })
            .catch(() => alert('Error updating patient'));
        });
    }
}

if (page === 'manage_patient.php') {
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete this patient?')) {
                const id = this.getAttribute('data-id');
                fetch(`ajax/delete_patient.php?id=${id}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            loadPage('manage_patient.php');
                        } else {
                            alert(data.error || 'Failed to delete patient');
                        }
                    });
            }
        });
    });

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            loadPage(`edit_patient.php?id=${id}`);
        });
    });
}






      // Attach handlers if dep.php
      if (page === 'dep.php') attachDepHandlers();
    })
    .catch(() => {
      document.getElementById("mainContent").innerHTML = "<p>Error loading page.</p>";
    });
}

// Department page handlers
function attachDepHandlers() {
  const responseDiv = document.getElementById('responseMessage');

  // --- Add Department ---
  const deptForm = document.getElementById('addDeptForm');
  if (deptForm) {
    deptForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(deptForm);

      fetch('ajax/dep.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
          deptForm.reset();
          loadPage('dep.php'); // reload table
        } else if (data.error) {
          responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
        }
      })
      .catch(() => alert('Failed to add department'));
    });
  }

  // --- Load Slots when selecting department ---
  const deptSelect = document.getElementById('departmentSelect');
  if (deptSelect) {
    deptSelect.addEventListener('change', function() {
      const formData = new FormData();
      formData.append('department_id', this.value);

      fetch('ajax/load_slots.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.text())
      .then(html => {
        document.getElementById('slotsContainer').innerHTML = html;

        // Now reattach Save Slots handler
        attachSlotFormHandler();
      })
      .catch(err => console.error("Failed to load slots:", err));
    });
  }

  // --- Delete Department ---
  document.querySelectorAll('.deleteDeptBtn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      if (!confirm("Delete this department?")) return;

      fetch('ajax/dep.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'delete_id=' + this.dataset.id
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
          loadPage('dep.php'); // reload table
        }
      })
      .catch(() => alert('Failed to delete department'));
    });
  });

  // Attach slot form if already rendered
  attachSlotFormHandler();
}


// Separate function for saving slots
function attachSlotFormHandler() {
  const slotForm = document.getElementById('slotForm');
  if (slotForm) {
    slotForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(slotForm);

      fetch('ajax/dep.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        // Select responseDiv inside the form
        const responseDiv = slotForm.querySelector('#slotResponseMessage');

        if (data.success) {
          responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;

          // Optional: fade out after 3 seconds
          setTimeout(() => {
            responseDiv.innerHTML = '';
          }, 3000);

          // Reload slots for the selected department
          const deptSelect = document.getElementById('departmentSelect');
          if (deptSelect && deptSelect.value) {
            const reloadData = new FormData();
            reloadData.append('department_id', deptSelect.value);

            fetch('ajax/load_slots.php', {
              method: 'POST',
              body: reloadData
            })
            .then(res => res.text())
            .then(html => {
              document.getElementById('slotsContainer').innerHTML = html;
              attachSlotFormHandler(); // reattach handler to the new form
            })
            .catch(err => console.error("Failed to reload slots:", err));
          }
        } else if (data.error) {
          responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
        }
      })
      .catch(() => alert('Failed to save slots'));
    });
  }
}



    






// Accordion toggle
function toggleAccordion(id) {
  const accordions = document.querySelectorAll(".accordion-content");
  accordions.forEach(acc => {
    if (acc.id !== id) acc.style.display = "none";
  });
  const content = document.getElementById(id);
  if (content) content.style.display = (content.style.display === "block") ? "none" : "block";
}

// Logout
function confirmLogout() {
  if (confirm("Are you sure you want to logout?")) {
    window.location.href = "logout.php";
  }
}
</script>




</body>
</html>
